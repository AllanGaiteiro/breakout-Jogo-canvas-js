function playerInfo() {
    return 'teste'
}